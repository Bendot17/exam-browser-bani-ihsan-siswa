# Exam Browser Siswa — Yayasan Bani Ihsan

APK WebView untuk portal peserta didik:
https://siswa-ujian-bani-ihsan.pages.dev/

## Fitur
- Ikon dan identitas aplikasi menggunakan logo yang disertakan.
- Tombol Back menampilkan konfirmasi keluar; tidak ada tombol keluar di header.
- Layar imersif, layar tetap menyala, JavaScript dan penyimpanan web aktif.
- Navigasi web dibatasi ke domain portal siswa.
- Meminta Android memulai Lock Task / Screen Pinning saat aplikasi dibuka.

## Batasan penting pada HP pribadi (BYOD)
Pada perangkat pribadi yang tidak dikelola sekolah, `startLockTask()` biasanya hanya meminta pengguna mengaktifkan Screen Pinning. Ini TIDAK menjamin Home, Recent Apps, panel notifikasi, pop-up sistem, split screen, atau akses ke aplikasi lain terkunci sepenuhnya. Pengguna masih dapat keluar dari Screen Pinning melalui mekanisme sistem Android yang berbeda menurut merek/versi.

Penguncian penuh memerlukan perangkat yang disiapkan sebagai Device Owner / fully managed device dan kebijakan Lock Task oleh administrator. APK biasa tidak dapat melewati batas keamanan Android atau memaksa kebijakan itu pada HP pribadi tanpa konfigurasi.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`.
Artifact: `Exam-Browser-Siswa-APK`.
