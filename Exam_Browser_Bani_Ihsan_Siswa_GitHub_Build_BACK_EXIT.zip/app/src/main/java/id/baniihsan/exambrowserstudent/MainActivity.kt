package id.baniihsan.exambrowserstudent

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val studentUrl = "https://siswa-ujian-bani-ihsan.pages.dev/"
    private val allowedHost = "siswa-ujian-bani-ihsan.pages.dev"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(21, 91, 45)
        window.navigationBarColor = Color.BLACK
        applyImmersiveMode()
        buildScreen()
        if (savedInstanceState == null) web.loadUrl(studentUrl)
        else web.restoreState(savedInstanceState)
        // On ordinary phones Android asks the user to confirm screen pinning.
        // On managed/Device Owner devices this can become true kiosk lock task mode.
        try { startLockTask() } catch (_: Exception) { }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 249, 246))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 8, 12, 8)
            setBackgroundColor(Color.rgb(21, 91, 45))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.yayasan_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(48, 48))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10,0,4,0) }
        titles.addView(TextView(this).apply {
            text = "EXAM BROWSER"; setTextColor(Color.WHITE); textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        })
        titles.addView(TextView(this).apply {
            text = "UJIAN SISWA • YAYASAN BANI IHSAN"; setTextColor(Color.rgb(225,245,225)); textSize = 9.5f
        })
        header.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != allowedHost
                }
            }
        }
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Keluar dari Exam Browser?")
            .setMessage("Pastikan Anda sudah menyelesaikan ujian atau mendapat izin pengawas.")
            .setNegativeButton("BATAL", null)
            .setPositiveButton("KELUAR") { _, _ ->
                try { stopLockTask() } catch (_: Exception) { }
                finish()
            }
            .show()
    }

    private fun applyImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // Back is the only in-app exit route; Android system navigation remains subject to device policy.
        confirmExit()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
