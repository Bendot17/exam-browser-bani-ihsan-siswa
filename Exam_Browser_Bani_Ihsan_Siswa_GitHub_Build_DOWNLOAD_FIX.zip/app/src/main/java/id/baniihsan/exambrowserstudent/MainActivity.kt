package id.baniihsan.exambrowserstudent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Typeface
import android.util.Base64
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val studentUrl = "https://siswa-ujian-bani-ihsan.pages.dev/"
    private val allowedHost = "siswa-ujian-bani-ihsan.pages.dev"

    private var pendingDownloadBytes: ByteArray? = null
    private var pendingDownloadMime: String = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private var pendingDownloadName: String = "Nilai_Ujian_Bani_Ihsan.xlsx"
    private val createFileRequest = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(21, 91, 45)
        window.navigationBarColor = Color.BLACK
        applyImmersiveMode()
        buildScreen()
        if (savedInstanceState == null) web.loadUrl(studentUrl)
        else web.restoreState(savedInstanceState)
        try { startLockTask() } catch (_: Exception) { }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 249, 246))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 8, 12, 8)
            setBackgroundColor(Color.rgb(21, 91, 45))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.yayasan_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(48, 48))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10,0,4,0) }
        titles.addView(TextView(this).apply {
            text = "EXAM BROWSER"; setTextColor(Color.WHITE); textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        })
        titles.addView(TextView(this).apply {
            text = "UJIAN SISWA • YAYASAN BANI IHSAN"; setTextColor(Color.rgb(225,245,225)); textSize = 9.5f
        })
        header.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.setSupportZoom(false)
            addJavascriptInterface(DownloadBridge(), "AndroidFileDownload")
            webChromeClient = WebChromeClient()
            setDownloadListener { url, _, contentDisposition, mimeType, _ ->
                // Handles ordinary HTTP(S) downloads. Blob downloads are handled by DownloadBridge.
                if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "Tidak dapat membuka tautan unduhan.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != allowedHost
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url?.startsWith("https://$allowedHost") == true) {
                        installBlobDownloadSupport()
                    }
                }
            }
        }
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun installBlobDownloadSupport() {
        val script = """
            (function() {
              if (window.__baniIhsanDownloadHookInstalled) return;
              window.__baniIhsanDownloadHookInstalled = true;
              document.addEventListener('click', function(event) {
                var link = event.target && event.target.closest ? event.target.closest('a[download]') : null;
                if (!link) return;
                var href = link.href || '';
                if (!href.startsWith('blob:')) return;
                event.preventDefault();
                event.stopPropagation();
                var filename = link.getAttribute('download') || 'Nilai_Ujian_Bani_Ihsan.xlsx';
                fetch(href).then(function(response) { return response.blob(); }).then(function(blob) {
                  var reader = new FileReader();
                  reader.onloadend = function() {
                    var dataUrl = String(reader.result || '');
                    var base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    AndroidFileDownload.saveFile(filename, blob.type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', base64);
                  };
                  reader.readAsDataURL(blob);
                }).catch(function() {
                  alert('File Excel tidak dapat disiapkan. Silakan coba kembali.');
                });
              }, true);
            })();
        """.trimIndent()
        web.evaluateJavascript(script, null)
    }

    private inner class DownloadBridge {
        @JavascriptInterface
        fun saveFile(fileName: String?, mimeType: String?, base64Data: String?) {
            runOnUiThread {
                try {
                    val safeName = (fileName ?: "Nilai_Ujian_Bani_Ihsan.xlsx")
                        .substringAfterLast("/")
                        .substringAfterLast("\\")
                        .ifBlank { "Nilai_Ujian_Bani_Ihsan.xlsx" }
                    val encoded = base64Data ?: ""
                    val bytes = Base64.decode(encoded, Base64.DEFAULT)
                    if (bytes.isEmpty()) {
                        Toast.makeText(this@MainActivity, "File Excel kosong.", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    pendingDownloadBytes = bytes
                    pendingDownloadMime = mimeType?.takeIf { it.isNotBlank() }
                        ?: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    pendingDownloadName = safeName
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = pendingDownloadMime
                        putExtra(Intent.EXTRA_TITLE, pendingDownloadName)
                    }
                    startActivityForResult(intent, createFileRequest)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Gagal menyiapkan file Excel.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createFileRequest) return
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingDownloadBytes = null
            Toast.makeText(this, "Penyimpanan file dibatalkan.", Toast.LENGTH_SHORT).show()
            return
        }
        val bytes = pendingDownloadBytes
        pendingDownloadBytes = null
        if (bytes == null) return
        try {
            val output: OutputStream? = contentResolver.openOutputStream(data.data!!)
            output?.use { it.write(bytes) }
            Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Gagal menyimpan file. Coba pilih folder Download.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Keluar dari Exam Browser?")
            .setMessage("Pastikan Anda sudah menyelesaikan ujian atau mendapat izin pengawas.")
            .setNegativeButton("BATAL", null)
            .setPositiveButton("KELUAR") { _, _ ->
                try { stopLockTask() } catch (_: Exception) { }
                finish()
            }
            .show()
    }

    private fun applyImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        confirmExit()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
